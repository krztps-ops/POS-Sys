package com.lp.pos

enum class Permiso {
    // Ventas
    REALIZAR_VENTA,
    CANCELAR_VENTA,
    AUTORIZAR_DESCUENTO_BASICO,
    AUTORIZAR_DESCUENTO_ALTO,
    AUTORIZAR_DESCUENTO_TOTAL,
    
    // Productos
    VER_PRODUCTOS,
    AGREGAR_PRODUCTO,
    EDITAR_PRODUCTO,
    ELIMINAR_PRODUCTO,
    MODIFICAR_PRECIO,
    
    // Inventario
    VER_STOCK,
    AJUSTAR_INVENTARIO,
    REGISTRAR_ENTRADA_MERCANCIA,
    
    // Reportes
    VER_VENTAS_PROPIAS,
    VER_VENTAS_TODAS,
    VER_HISTORIAL_COMPLETO,
    GENERAR_REPORTES_BASICOS,
    GENERAR_REPORTES_AVANZADOS,
    EXPORTAR_DATOS,
    
    // Configuración
    VER_CONFIGURACION,
    EDITAR_CONFIGURACION,
    CONFIGURAR_IMPRESORA,
    CONFIGURAR_TICKET,
    
    // Usuarios
    VER_USUARIOS,
    CREAR_USUARIO,
    EDITAR_USUARIO,
    ELIMINAR_USUARIO,
    CAMBIAR_ROL,
    
    // Turnos
    ABRIR_TURNO_PROPIO,
    CERRAR_TURNO_PROPIO,
    VER_TURNOS_OTROS,
    CERRAR_TURNO_OTROS,
    
    // Auditoría
    VER_LOGS_LIMITADO,
    VER_LOGS_COMPLETO,
    
    // Impresión
    IMPRIMIR_TICKET_PROPIO,
    REIMPRIMIR_TICKETS,
    IMPRIMIR_REPORTES
}

enum class Rol(
    val nivel: Int,
    val permisos: Set<Permiso>,
    val limiteDescuento: Int
) {
    CAJERO(
        nivel = 1,
        limiteDescuento = 0,
        permisos = setOf(
            Permiso.REALIZAR_VENTA,
            Permiso.VER_PRODUCTOS,
            Permiso.VER_VENTAS_PROPIAS,
            Permiso.ABRIR_TURNO_PROPIO,
            Permiso.CERRAR_TURNO_PROPIO,
            Permiso.IMPRIMIR_TICKET_PROPIO,
            Permiso.VER_STOCK
        )
    ),
    GERENTE(
        nivel = 2,
        limiteDescuento = 20,
        permisos = setOf(
            Permiso.REALIZAR_VENTA,
            Permiso.VER_PRODUCTOS,
            Permiso.VER_VENTAS_PROPIAS,
            Permiso.ABRIR_TURNO_PROPIO,
            Permiso.CERRAR_TURNO_PROPIO,
            Permiso.IMPRIMIR_TICKET_PROPIO,
            Permiso.VER_STOCK,
            Permiso.CANCELAR_VENTA,
            Permiso.AUTORIZAR_DESCUENTO_BASICO,
            Permiso.VER_VENTAS_TODAS,
            Permiso.VER_HISTORIAL_COMPLETO,
            Permiso.GENERAR_REPORTES_BASICOS,
            Permiso.AJUSTAR_INVENTARIO,
            Permiso.REIMPRIMIR_TICKETS,
            Permiso.CERRAR_TURNO_OTROS,
            Permiso.VER_LOGS_LIMITADO,
            Permiso.VER_USUARIOS
        )
    ),
    ADMIN(
        nivel = 3,
        limiteDescuento = 100,
        permisos = Permiso.values().toSet()
    );
    
    fun tienePermiso(permiso: Permiso): Boolean = permisos.contains(permiso)
}

enum class MetodoPago {
    EFECTIVO,
    TARJETA,
    TRANSFERENCIA,
    MIXTO
}

enum class EstadoVenta {
    COMPLETADA,
    CANCELADA,
    PENDIENTE
}

enum class MotivoCancelacion {
    ERROR_CAPTURA,
    CLIENTE_CAMBIO_OPINION,
    FALTA_CAMBIO,
    PRODUCTO_DANADO,
    ERROR_PRECIO,
    DEVOLUCION_MERCANCIA,
    OTRO
}

enum class EstadoCancelacion {
    COMPLETADA,
    REVISANDO,
    RECHAZADA,
    SOSPECHOSA
}

enum class EstadoTurno {
    ABIERTO,
    CERRADO
}