package com.lp.pos

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {
    
    private lateinit var database: AppDatabase
    private lateinit var etPin: EditText
    private lateinit var btnLogin: Button
    private lateinit var btn1: Button
    private lateinit var btn2: Button
    private lateinit var btn3: Button
    private lateinit var btn4: Button
    private lateinit var btn5: Button
    private lateinit var btn6: Button
    private lateinit var btn7: Button
    private lateinit var btn8: Button
    private lateinit var btn9: Button
    private lateinit var btn0: Button
    private lateinit var btnBorrar: Button
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        
        database = AppDatabase.getDatabase(this)
        SessionManager.init(this)
        AuditoriaLogger.init(database)
        
        initViews()
        setupListeners()
    }
    
    private fun initViews() {
        etPin = findViewById(R.id.etPin)
        btnLogin = findViewById(R.id.btnLogin)
        btn1 = findViewById(R.id.btn1)
        btn2 = findViewById(R.id.btn2)
        btn3 = findViewById(R.id.btn3)
        btn4 = findViewById(R.id.btn4)
        btn5 = findViewById(R.id.btn5)
        btn6 = findViewById(R.id.btn6)
        btn7 = findViewById(R.id.btn7)
        btn8 = findViewById(R.id.btn8)
        btn9 = findViewById(R.id.btn9)
        btn0 = findViewById(R.id.btn0)
        btnBorrar = findViewById(R.id.btnBorrar)
        
        etPin.isFocusable = false
        etPin.isClickable = false
    }
    
    private fun setupListeners() {
        btn1.setOnClickListener { agregarDigito("1") }
        btn2.setOnClickListener { agregarDigito("2") }
        btn3.setOnClickListener { agregarDigito("3") }
        btn4.setOnClickListener { agregarDigito("4") }
        btn5.setOnClickListener { agregarDigito("5") }
        btn6.setOnClickListener { agregarDigito("6") }
        btn7.setOnClickListener { agregarDigito("7") }
        btn8.setOnClickListener { agregarDigito("8") }
        btn9.setOnClickListener { agregarDigito("9") }
        btn0.setOnClickListener { agregarDigito("0") }
        
        btnBorrar.setOnClickListener {
            val currentPin = etPin.text.toString()
            if (currentPin.isNotEmpty()) {
                etPin.setText(currentPin.dropLast(1))
            }
        }
        
        btnLogin.setOnClickListener {
            intentarLogin()
        }
    }
    
    private fun agregarDigito(digito: String) {
        val currentPin = etPin.text.toString()
        if (currentPin.length < 6) {
            etPin.setText(currentPin + digito)
        }
    }
    
    private fun intentarLogin() {
        val pin = etPin.text.toString()
        
        if (pin.isEmpty()) {
            Toast.makeText(this, "Ingresa tu PIN", Toast.LENGTH_SHORT).show()
            return
        }
        
        lifecycleScope.launch {
            try {
                val pinCifrado = EncryptionHelper.cifrarPin(pin)
                val usuario = database.usuarioDao().getUsuarioByPin(pinCifrado)
                
                if (usuario != null) {
                    // Login exitoso
                    SessionManager.setUsuarioActual(usuario)
                    AuditoriaLogger.logLogin(usuario, true)
                    
                    // Verificar si tiene turno abierto
                    val turnoAbierto = database.turnoDao().getTurnoAbierto(usuario.id)
                    
                    if (turnoAbierto != null) {
                        SessionManager.setTurnoActual(turnoAbierto)
                        irAlPOS()
                    } else {
                        // Necesita abrir turno
                        mostrarDialogoAperturaTurno(usuario)
                    }
                } else {
                    // Login fallido
                    Toast.makeText(this@LoginActivity, "PIN incorrecto", Toast.LENGTH_SHORT).show()
                    etPin.setText("")
                    
                    // Log de intento fallido
                    val log = LogAuditoria(
                        usuarioId = 0,
                        usuarioNombre = "Desconocido",
                        rol = Rol.CAJERO,
                        accion = "LOGIN_FALLIDO",
                        modulo = "AUTENTICACION",
                        exito = false,
                        detalles = "PIN incorrecto"
                    )
                    database.logAuditoriaDao().insertLog(log)
                }
            } catch (e: Exception) {
                Toast.makeText(this@LoginActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun mostrarDialogoAperturaTurno(usuario: Usuario) {
        val builder = android.app.AlertDialog.Builder(this)
        builder.setTitle("Apertura de Turno")
        builder.setMessage("Ingresa el fondo inicial de caja:")
        
        val input = EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        input.hint = "Ej: 500.00"
        builder.setView(input)
        
        builder.setPositiveButton("Abrir Turno") { dialog, _ ->
            val fondoStr = input.text.toString()
            if (fondoStr.isNotEmpty()) {
                val fondo = fondoStr.toDoubleOrNull() ?: 0.0
                abrirTurno(usuario, fondo)
            } else {
                Toast.makeText(this, "Ingresa un monto válido", Toast.LENGTH_SHORT).show()
            }
            dialog.dismiss()
        }
        
        builder.setNegativeButton("Cancelar") { dialog, _ ->
            SessionManager.logout()
            dialog.dismiss()
        }
        
        builder.setCancelable(false)
        builder.show()
    }
    
    private fun abrirTurno(usuario: Usuario, fondoInicial: Double) {
        lifecycleScope.launch {
            try {
                val turno = Turno(
                    usuarioId = usuario.id,
                    apertura = System.currentTimeMillis(),
                    fondoInicial = fondoInicial,
                    estado = EstadoTurno.ABIERTO
                )
                
                val turnoId = database.turnoDao().insertTurno(turno)
                val turnoCreado = turno.copy(id = turnoId.toInt())
                SessionManager.setTurnoActual(turnoCreado)
                
                AuditoriaLogger.log(
                    accion = "TURNO_ABIERTO",
                    modulo = "TURNOS",
                    datosNuevos = turno,
                    detalles = "Turno abierto con fondo inicial: ${FormatHelper.formatearMoneda(fondoInicial)}"
                )
                
                irAlPOS()
            } catch (e: Exception) {
                Toast.makeText(this@LoginActivity, "Error al abrir turno: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun irAlPOS() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}