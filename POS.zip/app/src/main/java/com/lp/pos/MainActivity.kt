package com.lp.pos

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    
    private lateinit var database: AppDatabase
    private lateinit var recyclerView: RecyclerView
    private lateinit var tvTotal: TextView
    private lateinit var tvUsuario: TextView
    private lateinit var btnCobrar: Button
    private lateinit var btnCerrarSesion: Button
    private lateinit var adapter: ProductoAdapter
    private var productos = listOf<Producto>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Verificar si hay sesión activa
        SessionManager.init(this)
        if (!SessionManager.isLoggedIn()) {
            irAlLogin()
            return
        }
        
        setContentView(R.layout.activity_main)
        
        database = AppDatabase.getDatabase(this)
        AuditoriaLogger.init(database)
        
        initViews()
        cargarProductos()
        actualizarInterfaz()
    }
    
    private fun initViews() {
        recyclerView = findViewById(R.id.recyclerViewProductos)
        tvTotal = findViewById(R.id.tvTotal)
        tvUsuario = findViewById(R.id.tvUsuario)
        btnCobrar = findViewById(R.id.btnCobrar)
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion)
        
        recyclerView.layoutManager = LinearLayoutManager(this)
        
        btnCobrar.setOnClickListener {
            mostrarDialogoPago()
        }
        
        btnCerrarSesion.setOnClickListener {
            cerrarSesion()
        }
    }
    
    private fun cargarProductos() {
        lifecycleScope.launch {
            try {
                productos = database.productoDao().getProductosActivos()
                adapter = ProductoAdapter(productos) { producto ->
                    agregarAlCarrito(producto)
                }
                recyclerView.adapter = adapter
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun agregarAlCarrito(producto: Producto) {
        if (producto.stock <= 0) {
            Toast.makeText(this, "Producto sin stock", Toast.LENGTH_SHORT).show()
            return
        }
        
        CarritoManager.agregarProducto(producto)
        actualizarTotal()
        Toast.makeText(this, "${producto.nombre} agregado", Toast.LENGTH_SHORT).show()
    }
    
    private fun actualizarTotal() {
        val total = CarritoManager.getTotal()
        val formato = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
        tvTotal.text = "Total: ${formato.format(total)}"
    }
    
    private fun actualizarInterfaz() {
        val usuario = SessionManager.getUsuarioActual()
        if (usuario != null) {
            tvUsuario.text = "${usuario.nombre} (${usuario.rol.name})"
        }
        actualizarTotal()
    }
    
    private fun mostrarDialogoPago() {
        if (CarritoManager.isEmpty()) {
            Toast.makeText(this, "No hay productos en el carrito", Toast.LENGTH_SHORT).show()
            return
        }
        
        val total = CarritoManager.getTotal()
        val formato = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
        
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Método de Pago")
        builder.setMessage("Total a cobrar: ${formato.format(total)}")
        
        val metodos = arrayOf("Efectivo", "Tarjeta", "Transferencia")
        
        builder.setItems(metodos) { dialog, which ->
            val metodoPago = when (which) {
                0 -> MetodoPago.EFECTIVO
                1 -> MetodoPago.TARJETA
                2 -> MetodoPago.TRANSFERENCIA
                else -> MetodoPago.EFECTIVO
            }
            
            if (metodoPago == MetodoPago.EFECTIVO) {
                mostrarDialogoEfectivo(total)
            } else {
                procesarVenta(metodoPago)
            }
        }
        
        builder.setNegativeButton("Cancelar", null)
        builder.show()
    }
    
    private fun mostrarDialogoEfectivo(total: Double) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Pago en Efectivo")
        
        val input = android.widget.EditText(this)
        input.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        input.hint = "Monto recibido"
        builder.setView(input)
        
        builder.setPositiveButton("Confirmar") { dialog, _ ->
            val montoStr = input.text.toString()
            if (montoStr.isNotEmpty()) {
                val monto = montoStr.toDoubleOrNull() ?: 0.0
                if (monto >= total) {
                    val cambio = monto - total
                    val formato = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
                    Toast.makeText(this, "Cambio: ${formato.format(cambio)}", Toast.LENGTH_LONG).show()
                    procesarVenta(MetodoPago.EFECTIVO)
                } else {
                    Toast.makeText(this, "Monto insuficiente", Toast.LENGTH_SHORT).show()
                }
            }
            dialog.dismiss()
        }
        
        builder.setNegativeButton("Cancelar", null)
        builder.show()
    }
    
    private fun procesarVenta(metodoPago: MetodoPago) {
        val usuario = SessionManager.getUsuarioActual() ?: return
        
        lifecycleScope.launch {
            try {
                // Crear venta
                val folio = FolioGenerator.generarFolio()
                val total = CarritoManager.getTotal()
                
                val venta = Venta(
                    folio = folio,
                    usuarioId = usuario.id,
                    total = total,
                    metodoPago = metodoPago,
                    estado = EstadoVenta.COMPLETADA
                )
                
                val ventaId = database.ventaDao().insertVenta(venta)
                
                // Crear detalles
                val detalles = CarritoManager.getItems().map { item ->
                    VentaDetalle(
                        ventaId = ventaId.toInt(),
                        productoId = item.producto.id,
                        nombreProducto = item.producto.nombre,
                        cantidad = item.cantidad,
                        precioUnitario = item.producto.precio,
                        subtotal = item.subtotal
                    )
                }
                
                database.ventaDetalleDao().insertDetalles(detalles)
                
                // Descontar stock
                CarritoManager.getItems().forEach { item ->
                    database.productoDao().descontarStock(item.producto.id, item.cantidad)
                }
                
                // Log de auditoría
                AuditoriaLogger.logVenta(venta, detalles)
                
                // Limpiar carrito
                CarritoManager.limpiar()
                actualizarTotal()
                
                // Mostrar confirmación
                Toast.makeText(this@MainActivity, "Venta realizada: $folio", Toast.LENGTH_LONG).show()
                
                // TODO: Aquí se imprimiría el ticket
                // imprimirTicket(venta, detalles)
                
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Error al procesar venta: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun cerrarSesion() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Cerrar Sesión")
        builder.setMessage("¿Deseas cerrar sesión?")
        
        builder.setPositiveButton("Sí") { _, _ ->
            AuditoriaLogger.log(
                accion = "LOGOUT",
                modulo = "AUTENTICACION",
                detalles = "Cierre de sesión"
            )
            
            SessionManager.logout()
            CarritoManager.limpiar()
            irAlLogin()
        }
        
        builder.setNegativeButton("No", null)
        builder.show()
    }
    
    private fun irAlLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}

class ProductoAdapter(
    private val productos: List<Producto>,
    private val onProductoClick: (Producto) -> Unit
) : RecyclerView.Adapter<ProductoAdapter.ProductoViewHolder>() {
    
    class ProductoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvNombre: TextView = view.findViewById(R.id.tvNombreProducto)
        val tvPrecio: TextView = view.findViewById(R.id.tvPrecioProducto)
        val btnAgregar: Button = view.findViewById(R.id.btnAgregarProducto)
    }
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductoViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_producto, parent, false)
        return ProductoViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: ProductoViewHolder, position: Int) {
        val producto = productos[position]
        val formato = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
        
        holder.tvNombre.text = producto.nombre
        holder.tvPrecio.text = formato.format(producto.precio)
        holder.btnAgregar.setOnClickListener {
            onProductoClick(producto)
        }
    }
    
    override fun getItemCount() = productos.size
}