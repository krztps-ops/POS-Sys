package com.lp.pos

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.security.MessageDigest
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

// ==================== SESSION MANAGER ====================

object SessionManager {
    private var usuarioActual: Usuario? = null
    private var turnoActual: Turno? = null
    private lateinit var prefs: SharedPreferences
    
    fun init(context: Context) {
        prefs = context.getSharedPreferences("pos_session", Context.MODE_PRIVATE)
    }
    
    fun setUsuarioActual(usuario: Usuario) {
        usuarioActual = usuario
        prefs.edit().putInt("usuario_id", usuario.id).apply()
    }
    
    fun getUsuarioActual(): Usuario? = usuarioActual
    
    fun setTurnoActual(turno: Turno) {
        turnoActual = turno
        prefs.edit().putInt("turno_id", turno.id).apply()
    }
    
    fun getTurnoActual(): Turno? = turnoActual
    
    fun isLoggedIn(): Boolean = usuarioActual != null
    
    fun logout() {
        usuarioActual = null
        turnoActual = null
        prefs.edit().clear().apply()
    }
    
    fun getUsuarioId(): Int = usuarioActual?.id ?: 0
}

// ==================== AUDITORIA LOGGER ====================

object AuditoriaLogger {
    private lateinit var database: AppDatabase
    
    fun init(db: AppDatabase) {
        database = db
    }
    
    fun log(
        accion: String,
        modulo: String,
        datosAnteriores: Any? = null,
        datosNuevos: Any? = null,
        exito: Boolean = true,
        detalles: String? = null
    ) {
        val usuario = SessionManager.getUsuarioActual() ?: return
        
        CoroutineScope(Dispatchers.IO).launch {
            val gson = Gson()
            val log = LogAuditoria(
                usuarioId = usuario.id,
                usuarioNombre = usuario.nombre,
                rol = usuario.rol,
                accion = accion,
                modulo = modulo,
                datosAnteriores = datosAnteriores?.let { gson.toJson(it) },
                datosNuevos = datosNuevos?.let { gson.toJson(it) },
                exito = exito,
                detalles = detalles
            )
            database.logAuditoriaDao().insertLog(log)
        }
    }
    
    fun logLogin(usuario: Usuario, exito: Boolean) {
        CoroutineScope(Dispatchers.IO).launch {
            val log = LogAuditoria(
                usuarioId = if (exito) usuario.id else 0,
                usuarioNombre = usuario.nombre,
                rol = usuario.rol,
                accion = if (exito) "LOGIN_EXITOSO" else "LOGIN_FALLIDO",
                modulo = "AUTENTICACION",
                exito = exito,
                detalles = if (exito) "Inicio de sesión exitoso" else "PIN incorrecto"
            )
            database.logAuditoriaDao().insertLog(log)
        }
    }
    
    fun logVenta(venta: Venta, detalles: List<VentaDetalle>) {
        log(
            accion = "VENTA_REALIZADA",
            modulo = "VENTAS",
            datosNuevos = mapOf(
                "venta" to venta,
                "detalles" to detalles
            ),
            detalles = "Venta ${venta.folio} por $${venta.total}"
        )
    }
    
    fun logCancelacion(
        venta: Venta,
        cancelacion: Cancelacion,
        autorizadoPor: Usuario
    ) {
        log(
            accion = "VENTA_CANCELADA",
            modulo = "CANCELACIONES",
            datosAnteriores = venta,
            datosNuevos = cancelacion,
            detalles = "Venta ${venta.folio} cancelada. Motivo: ${cancelacion.motivo}. Autorizado por: ${autorizadoPor.nombre}"
        )
    }
}

// ==================== PERMISOS HELPER ====================

object PermisosHelper {
    
    fun validarPermiso(permiso: Permiso): Boolean {
        val usuario = SessionManager.getUsuarioActual() ?: return false
        return usuario.rol.tienePermiso(permiso)
    }
    
    fun validarDescuento(porcentaje: Int): Boolean {
        val usuario = SessionManager.getUsuarioActual() ?: return false
        return when {
            porcentaje <= 0 -> true
            porcentaje <= 20 -> usuario.rol.tienePermiso(Permiso.AUTORIZAR_DESCUENTO_BASICO)
            porcentaje <= 50 -> usuario.rol.tienePermiso(Permiso.AUTORIZAR_DESCUENTO_ALTO)
            else -> usuario.rol.tienePermiso(Permiso.AUTORIZAR_DESCUENTO_TOTAL)
        }
    }
    
    fun requiereAutorizacion(accion: Permiso): Boolean {
        return !validarPermiso(accion)
    }
    
    fun puedeAccederModulo(modulo: String): Boolean {
        val usuario = SessionManager.getUsuarioActual() ?: return false
        
        return when (modulo) {
            "PRODUCTOS" -> validarPermiso(Permiso.VER_PRODUCTOS)
            "REPORTES" -> validarPermiso(Permiso.GENERAR_REPORTES_BASICOS)
            "CONFIGURACION" -> validarPermiso(Permiso.VER_CONFIGURACION)
            "USUARIOS" -> validarPermiso(Permiso.VER_USUARIOS)
            else -> true
        }
    }
}

// ==================== CANCELACION VALIDATOR ====================

object CancelacionValidator {
    
    fun validarCancelacion(
        venta: Venta,
        database: AppDatabase
    ): ResultadoValidacion {
        val usuario = SessionManager.getUsuarioActual()
            ?: return ResultadoValidacion(
                permitido = false,
                mensaje = "No hay sesión activa"
            )
        
        // Regla 1: Cajero no puede cancelar
        if (usuario.rol == Rol.CAJERO) {
            return ResultadoValidacion(
                permitido = false,
                mensaje = "Los cajeros no pueden cancelar ventas"
            )
        }
        
        // Regla 2: No puede cancelar su propia venta
        if (venta.usuarioId == usuario.id) {
            return ResultadoValidacion(
                permitido = false,
                mensaje = "No puedes cancelar tus propias ventas"
            )
        }
        
        // Regla 3: Verificar límite de tiempo
        val tiempoTranscurrido = System.currentTimeMillis() - venta.timestamp
        val minutos = tiempoTranscurrido / (1000 * 60)
        
        return when {
            minutos < 5 -> ResultadoValidacion(
                permitido = true,
                requiereAdmin = false,
                requiereFoto = false,
                mensaje = "Cancelación permitida"
            )
            minutos < 30 -> ResultadoValidacion(
                permitido = true,
                requiereAdmin = false,
                requiereFoto = true,
                mensaje = "Requiere foto del ticket"
            )
            minutos < 1440 -> ResultadoValidacion(
                permitido = true,
                requiereAdmin = true,
                requiereFoto = true,
                mensaje = "Requiere autorización de Administrador y foto"
            )
            else -> ResultadoValidacion(
                permitido = true,
                requiereAdmin = true,
                requiereFoto = true,
                mensaje = "Venta antigua. Requiere Admin + justificación detallada"
            )
        }
    }
    
    suspend fun verificarLimiteDiario(database: AppDatabase): Boolean {
        val usuarioId = SessionManager.getUsuarioId()
        val cancelacionesHoy = database.cancelacionDao().getCantidadCancelacionesHoy(usuarioId)
        return cancelacionesHoy < 10 // límite diario
    }
}

// ==================== ENCRYPTION HELPER ====================

object EncryptionHelper {
    
    fun cifrarPin(pin: String): String {
        val bytes = pin.toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(bytes)
        return digest.fold("") { str, it -> str + "%02x".format(it) }
    }
    
    fun verificarPin(pinIngresado: String, pinCifrado: String): Boolean {
        return cifrarPin(pinIngresado) == pinCifrado
    }
}

// ==================== FOLIO GENERATOR ====================

object FolioGenerator {
    
    fun generarFolio(prefijo: String = "V"): String {
        val timestamp = System.currentTimeMillis()
        val random = (1000..9999).random()
        return "$prefijo${timestamp}${random}"
    }
    
    fun generarFolioCancelacion(): String = generarFolio("C")
}

// ==================== FORMAT HELPERS ====================

object FormatHelper {
    
    private val formatoMoneda = NumberFormat.getCurrencyInstance(Locale("es", "MX"))
    private val formatoFecha = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "MX"))
    private val formatoFechaCorta = SimpleDateFormat("dd/MM/yyyy", Locale("es", "MX"))
    
    fun formatearMoneda(cantidad: Double): String {
        return formatoMoneda.format(cantidad)
    }
    
    fun formatearFecha(timestamp: Long): String {
        return formatoFecha.format(Date(timestamp))
    }
    
    fun formatearFechaCorta(timestamp: Long): String {
        return formatoFechaCorta.format(Date(timestamp))
    }
    
    fun obtenerInicioDelDia(): Long {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        return calendar.timeInMillis
    }
    
    fun obtenerFinDelDia(): Long {
        val calendar = Calendar.getInstance()
        calendar.set(Calendar.HOUR_OF_DAY, 23)
        calendar.set(Calendar.MINUTE, 59)
        calendar.set(Calendar.SECOND, 59)
        calendar.set(Calendar.MILLISECOND, 999)
        return calendar.timeInMillis
    }
}

// ==================== CARRITO MANAGER ====================

object CarritoManager {
    private val items = mutableListOf<ProductoEnCarrito>()
    
    fun agregarProducto(producto: Producto) {
        val itemExistente = items.find { it.producto.id == producto.id }
        if (itemExistente != null) {
            itemExistente.cantidad++
        } else {
            items.add(ProductoEnCarrito(producto, 1))
        }
    }
    
    fun quitarProducto(productoId: Int) {
        items.removeIf { it.producto.id == productoId }
    }
    
    fun actualizarCantidad(productoId: Int, cantidad: Int) {
        items.find { it.producto.id == productoId }?.cantidad = cantidad
    }
    
    fun getItems(): List<ProductoEnCarrito> = items.toList()
    
    fun getTotal(): Double = items.sumOf { it.subtotal }
    
    fun getCantidadItems(): Int = items.sumOf { it.cantidad }
    
    fun limpiar() {
        items.clear()
    }
    
    fun isEmpty(): Boolean = items.isEmpty()
}