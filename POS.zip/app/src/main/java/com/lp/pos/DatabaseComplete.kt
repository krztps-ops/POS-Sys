package com.lp.pos

import android.content.Context
import androidx.room.*
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.security.MessageDigest

// ==================== DAOs ====================

@Dao
interface UsuarioDao {
    @Query("SELECT * FROM usuarios WHERE activo = 1")
    suspend fun getUsuariosActivos(): List<Usuario>
    
    @Query("SELECT * FROM usuarios WHERE id = :id")
    suspend fun getUsuarioById(id: Int): Usuario?
    
    @Query("SELECT * FROM usuarios WHERE pinCifrado = :pinCifrado AND activo = 1 LIMIT 1")
    suspend fun getUsuarioByPin(pinCifrado: String): Usuario?
    
    @Insert
    suspend fun insertUsuario(usuario: Usuario): Long
    
    @Update
    suspend fun updateUsuario(usuario: Usuario)
    
    @Query("UPDATE usuarios SET activo = 0 WHERE id = :id")
    suspend fun desactivarUsuario(id: Int)
}

@Dao
interface ProductoDao {
    @Query("SELECT * FROM productos WHERE activo = 1 ORDER BY nombre")
    suspend fun getProductosActivos(): List<Producto>
    
    @Query("SELECT * FROM productos WHERE id = :id")
    suspend fun getProductoById(id: Int): Producto?
    
    @Query("SELECT * FROM productos WHERE codigoBarras = :codigo AND activo = 1 LIMIT 1")
    suspend fun getProductoByCodigo(codigo: String): Producto?
    
    @Query("SELECT * FROM productos WHERE stock <= stockMinimo AND activo = 1")
    suspend fun getProductosStockBajo(): List<Producto>
    
    @Insert
    suspend fun insertProducto(producto: Producto): Long
    
    @Update
    suspend fun updateProducto(producto: Producto)
    
    @Query("UPDATE productos SET stock = stock - :cantidad WHERE id = :id")
    suspend fun descontarStock(id: Int, cantidad: Int)
    
    @Query("UPDATE productos SET stock = stock + :cantidad WHERE id = :id")
    suspend fun aumentarStock(id: Int, cantidad: Int)
    
    @Query("UPDATE productos SET activo = 0 WHERE id = :id")
    suspend fun desactivarProducto(id: Int)
}

@Dao
interface VentaDao {
    @Query("SELECT * FROM ventas ORDER BY timestamp DESC LIMIT 100")
    suspend fun getVentasRecientes(): List<Venta>
    
    @Query("SELECT * FROM ventas WHERE id = :id")
    suspend fun getVentaById(id: Int): Venta?
    
    @Query("SELECT * FROM ventas WHERE usuarioId = :usuarioId AND timestamp >= :desde ORDER BY timestamp DESC")
    suspend fun getVentasPorUsuario(usuarioId: Int, desde: Long): List<Venta>
    
    @Query("SELECT * FROM ventas WHERE timestamp >= :desde AND timestamp <= :hasta")
    suspend fun getVentasPorRango(desde: Long, hasta: Long): List<Venta>
    
    @Query("SELECT * FROM ventas WHERE DATE(timestamp/1000, 'unixepoch') = DATE('now') AND cancelada = 0")
    suspend fun getVentasDelDia(): List<Venta>
    
    @Query("SELECT SUM(total) FROM ventas WHERE DATE(timestamp/1000, 'unixepoch') = DATE('now') AND cancelada = 0")
    suspend fun getTotalVentasDelDia(): Double?
    
    @Insert
    suspend fun insertVenta(venta: Venta): Long
    
    @Update
    suspend fun updateVenta(venta: Venta)
    
    @Query("UPDATE ventas SET cancelada = 1, estado = 'CANCELADA' WHERE id = :id")
    suspend fun cancelarVenta(id: Int)
}

@Dao
interface VentaDetalleDao {
    @Query("SELECT * FROM venta_detalle WHERE ventaId = :ventaId")
    suspend fun getDetallesPorVenta(ventaId: Int): List<VentaDetalle>
    
    @Insert
    suspend fun insertDetalle(detalle: VentaDetalle): Long
    
    @Insert
    suspend fun insertDetalles(detalles: List<VentaDetalle>)
}

@Dao
interface LogAuditoriaDao {
    @Query("SELECT * FROM logs_auditoria ORDER BY timestamp DESC LIMIT 500")
    suspend fun getLogsRecientes(): List<LogAuditoria>
    
    @Query("SELECT * FROM logs_auditoria WHERE usuarioId = :usuarioId ORDER BY timestamp DESC LIMIT 100")
    suspend fun getLogsPorUsuario(usuarioId: Int): List<LogAuditoria>
    
    @Query("SELECT * FROM logs_auditoria WHERE timestamp >= :desde AND timestamp <= :hasta ORDER BY timestamp DESC")
    suspend fun getLogsPorRango(desde: Long, hasta: Long): List<LogAuditoria>
    
    @Query("SELECT * FROM logs_auditoria WHERE accion = :accion ORDER BY timestamp DESC LIMIT 100")
    suspend fun getLogsPorAccion(accion: String): List<LogAuditoria>
    
    @Insert
    suspend fun insertLog(log: LogAuditoria): Long
}

@Dao
interface CancelacionDao {
    @Query("SELECT * FROM cancelaciones ORDER BY timestamp DESC")
    suspend fun getCancelaciones(): List<Cancelacion>
    
    @Query("SELECT * FROM cancelaciones WHERE ventaId = :ventaId")
    suspend fun getCancelacionPorVenta(ventaId: Int): Cancelacion?
    
    @Query("SELECT * FROM cancelaciones WHERE usuarioQueCanceloId = :usuarioId AND timestamp >= :desde")
    suspend fun getCancelacionesPorUsuario(usuarioId: Int, desde: Long): List<Cancelacion>
    
    @Query("SELECT COUNT(*) FROM cancelaciones WHERE usuarioQueCanceloId = :usuarioId AND DATE(timestamp/1000, 'unixepoch') = DATE('now')")
    suspend fun getCantidadCancelacionesHoy(usuarioId: Int): Int
    
    @Insert
    suspend fun insertCancelacion(cancelacion: Cancelacion): Long
    
    @Update
    suspend fun updateCancelacion(cancelacion: Cancelacion)
}

@Dao
interface TurnoDao {
    @Query("SELECT * FROM turnos WHERE usuarioId = :usuarioId AND estado = 'ABIERTO' LIMIT 1")
    suspend fun getTurnoAbierto(usuarioId: Int): Turno?
    
    @Query("SELECT * FROM turnos WHERE usuarioId = :usuarioId ORDER BY apertura DESC LIMIT 10")
    suspend fun getTurnosPorUsuario(usuarioId: Int): List<Turno>
    
    @Query("SELECT * FROM turnos WHERE estado = 'ABIERTO'")
    suspend fun getTurnosAbiertos(): List<Turno>
    
    @Insert
    suspend fun insertTurno(turno: Turno): Long
    
    @Update
    suspend fun updateTurno(turno: Turno)
    
    @Query("UPDATE turnos SET estado = 'CERRADO', cierre = :cierre, efectivoFinal = :efectivoFinal, diferencia = :diferencia WHERE id = :id")
    suspend fun cerrarTurno(id: Int, cierre: Long, efectivoFinal: Double, diferencia: Double)
}

// ==================== BASE DE DATOS ====================

@Database(
    entities = [
        Usuario::class,
        Producto::class,
        Venta::class,
        VentaDetalle::class,
        LogAuditoria::class,
        Cancelacion::class,
        Turno::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun usuarioDao(): UsuarioDao
    abstract fun productoDao(): ProductoDao
    abstract fun ventaDao(): VentaDao
    abstract fun ventaDetalleDao(): VentaDetalleDao
    abstract fun logAuditoriaDao(): LogAuditoriaDao
    abstract fun cancelacionDao(): CancelacionDao
    abstract fun turnoDao(): TurnoDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pos_database"
                )
                .addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Inicializar con datos de prueba
                        INSTANCE?.let { database ->
                            CoroutineScope(Dispatchers.IO).launch {
                                inicializarDatos(database)
                            }
                        }
                    }
                })
                .build()
                INSTANCE = instance
                instance
            }
        }
        
        private suspend fun inicializarDatos(database: AppDatabase) {
            // Crear usuario admin por defecto
            val pinAdmin = cifrarPin("1234")
            val admin = Usuario(
                nombre = "Administrador",
                pinCifrado = pinAdmin,
                rol = Rol.ADMIN,
                activo = true
            )
            database.usuarioDao().insertUsuario(admin)
            
            // Crear productos de ejemplo
            val productosEjemplo = listOf(
                Producto(codigoBarras = "7501234567890", nombre = "Coca Cola 600ml", precio = 15.0, stock = 100),
                Producto(codigoBarras = "7501234567891", nombre = "Sabritas Original", precio = 18.0, stock = 80),
                Producto(codigoBarras = "7501234567892", nombre = "Agua Ciel 1L", precio = 12.0, stock = 120),
                Producto(codigoBarras = "7501234567893", nombre = "Gansito Marinela", precio = 10.0, stock = 60),
                Producto(codigoBarras = "7501234567894", nombre = "Chicles Trident", precio = 8.0, stock = 200)
            )
            
            productosEjemplo.forEach {
                database.productoDao().insertProducto(it)
            }
            
            // Log de inicialización
            val log = LogAuditoria(
                usuarioId = 1,
                usuarioNombre = "Sistema",
                rol = Rol.ADMIN,
                accion = "INICIALIZACION",
                modulo = "DATABASE",
                detalles = "Base de datos inicializada con usuario admin (PIN: 1234) y productos de ejemplo",
                exito = true
            )
            database.logAuditoriaDao().insertLog(log)
        }
        
        private fun cifrarPin(pin: String): String {
            val bytes = pin.toByteArray()
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(bytes)
            return digest.fold("") { str, it -> str + "%02x".format(it) }
        }
    }
}