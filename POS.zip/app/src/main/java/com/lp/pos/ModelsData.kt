package com.lp.pos

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

// ==================== ENTIDADES ====================

@Entity(tableName = "usuarios")
data class Usuario(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val nombre: String,
    val pinCifrado: String,
    @TypeConverters(Converters::class)
    val rol: Rol,
    val foto: String? = null,
    val activo: Boolean = true,
    val creadoEn: Long = System.currentTimeMillis()
)

@Entity(tableName = "productos")
data class Producto(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val codigoBarras: String,
    val nombre: String,
    val precio: Double,
    val stock: Int = 0,
    val stockMinimo: Int = 5,
    val categoria: String = "General",
    val activo: Boolean = true,
    val creadoEn: Long = System.currentTimeMillis()
)

@Entity(tableName = "ventas")
data class Venta(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val folio: String,
    val timestamp: Long = System.currentTimeMillis(),
    val usuarioId: Int,
    val total: Double,
    @TypeConverters(Converters::class)
    val metodoPago: MetodoPago,
    @TypeConverters(Converters::class)
    val estado: EstadoVenta = EstadoVenta.COMPLETADA,
    val cancelada: Boolean = false
)

@Entity(tableName = "venta_detalle")
data class VentaDetalle(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val ventaId: Int,
    val productoId: Int,
    val nombreProducto: String,
    val cantidad: Int,
    val precioUnitario: Double,
    val subtotal: Double
)

@Entity(tableName = "logs_auditoria")
data class LogAuditoria(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val usuarioId: Int,
    val usuarioNombre: String,
    @TypeConverters(Converters::class)
    val rol: Rol,
    val accion: String,
    val modulo: String,
    val datosAnteriores: String? = null,
    val datosNuevos: String? = null,
    val exito: Boolean = true,
    val detalles: String? = null
)

@Entity(tableName = "cancelaciones")
data class Cancelacion(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val ventaId: Int,
    val folioCancelacion: String,
    val usuarioQueVendioId: Int,
    val usuarioQueCanceloId: Int,
    val usuarioQueAutorizoId: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val tiempoTranscurrido: Long,
    @TypeConverters(Converters::class)
    val motivo: MotivoCancelacion,
    val descripcion: String,
    val clientePresente: Boolean,
    val productosDevueltos: Boolean,
    val fotoTicket: String? = null,
    val ventaOriginalJson: String,
    val montoOriginal: Double,
    @TypeConverters(Converters::class)
    val estado: EstadoCancelacion = EstadoCancelacion.COMPLETADA
)

@Entity(tableName = "turnos")
data class Turno(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val usuarioId: Int,
    val apertura: Long,
    val cierre: Long? = null,
    val fondoInicial: Double,
    val efectivoFinal: Double? = null,
    val diferencia: Double? = null,
    @TypeConverters(Converters::class)
    val estado: EstadoTurno = EstadoTurno.ABIERTO
)

// ==================== TYPE CONVERTERS ====================

class Converters {
    private val gson = Gson()
    
    @TypeConverter
    fun fromRol(value: Rol): String = value.name
    
    @TypeConverter
    fun toRol(value: String): Rol = Rol.valueOf(value)
    
    @TypeConverter
    fun fromMetodoPago(value: MetodoPago): String = value.name
    
    @TypeConverter
    fun toMetodoPago(value: String): MetodoPago = MetodoPago.valueOf(value)
    
    @TypeConverter
    fun fromEstadoVenta(value: EstadoVenta): String = value.name
    
    @TypeConverter
    fun toEstadoVenta(value: String): EstadoVenta = EstadoVenta.valueOf(value)
    
    @TypeConverter
    fun fromMotivoCancelacion(value: MotivoCancelacion): String = value.name
    
    @TypeConverter
    fun toMotivoCancelacion(value: String): MotivoCancelacion = MotivoCancelacion.valueOf(value)
    
    @TypeConverter
    fun fromEstadoCancelacion(value: EstadoCancelacion): String = value.name
    
    @TypeConverter
    fun toEstadoCancelacion(value: String): EstadoCancelacion = EstadoCancelacion.valueOf(value)
    
    @TypeConverter
    fun fromEstadoTurno(value: EstadoTurno): String = value.name
    
    @TypeConverter
    fun toEstadoTurno(value: String): EstadoTurno = EstadoTurno.valueOf(value)
}

// ==================== DATA CLASSES AUXILIARES ====================

data class ProductoEnCarrito(
    val producto: Producto,
    var cantidad: Int = 1
) {
    val subtotal: Double
        get() = producto.precio * cantidad
}

data class ResultadoValidacion(
    val permitido: Boolean,
    val requiereAdmin: Boolean = false,
    val requiereJustificacion: Boolean = true,
    val requiereFoto: Boolean = false,
    val mensaje: String
)

data class VentaCompleta(
    val venta: Venta,
    val detalles: List<VentaDetalle>,
    val usuario: Usuario
)